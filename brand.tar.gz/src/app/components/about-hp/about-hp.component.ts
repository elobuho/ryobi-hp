import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-about-hp',
  templateUrl: './about-hp.component.html',
  styleUrls: ['./about-hp.component.scss']
})
export class AboutHPComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
