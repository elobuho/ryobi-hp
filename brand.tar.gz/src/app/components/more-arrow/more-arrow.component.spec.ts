import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MoreArrowComponent } from './more-arrow.component';

describe('MoreArrowComponent', () => {
  let component: MoreArrowComponent;
  let fixture: ComponentFixture<MoreArrowComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MoreArrowComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MoreArrowComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
