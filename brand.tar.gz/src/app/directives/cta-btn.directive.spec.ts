import { CtaBtnDirective } from './cta-btn.directive';

describe('CtaBtnDirective', () => {
  it('should create an instance', () => {
    const directive = new CtaBtnDirective();
    expect(directive).toBeTruthy();
  });
});
